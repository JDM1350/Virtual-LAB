const close = document.querySelector(".responsive")
function close1() {

  if (!close.classList.contains("show")) {

    close.classList.add("show");
  } else {
    close.classList.remove("show");
  }

}
const con = document.getElementsByClassName("intro")
function close2() {

}


const b = document.querySelector(".bye");
function bye() {
  close.classList.remove("show")
}